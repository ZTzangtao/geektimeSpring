package geektime.spring.boot.sba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbaClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbaClientApplication.class, args);
	}

}
